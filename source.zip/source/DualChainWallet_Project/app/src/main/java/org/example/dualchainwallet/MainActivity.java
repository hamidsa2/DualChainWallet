package org.example.dualchainwallet;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.view.Gravity;
import android.widget.*;
import org.web3j.crypto.Bip32ECKeyPair;
import org.web3j.crypto.ECKeyPair;
import org.web3j.crypto.Keys;
import org.web3j.crypto.MnemonicUtils;
import org.web3j.crypto.Hash;
import org.web3j.utils.Numeric;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.Arrays;

public class MainActivity extends Activity {
    private EditText recoveryInput;
    private TextView mnemonicOut, tronOut, bscOut, status;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(20, 37, 63));
        getWindow().setNavigationBarColor(Color.rgb(20, 37, 63));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 22, 20, 22);
        root.setBackgroundColor(Color.rgb(246, 248, 252));

        TextView title = new TextView(this);
        title.setText("DualChain Wallet"); title.setTextSize(25); title.setTextColor(Color.rgb(20,37,63)); title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        TextView sub = new TextView(this);
        sub.setText("پروتوتایپ تولید عبارت بازیابی و آدرس برای TRON و BNB Smart Chain"); sub.setTextSize(14); sub.setPadding(0,8,0,14);
        root.addView(sub);

        TextView warn = new TextView(this);
        warn.setText("هشدار: این نسخه آزمایشی است؛ ارسال تراکنش، نمایش موجودی و ذخیره‌سازی امن کلید را پیاده‌سازی نکرده است. برای دارایی واقعی استفاده نکنید.");
        warn.setTextColor(Color.rgb(150,45,35)); warn.setTextSize(13); warn.setPadding(10,10,10,10); warn.setBackgroundColor(Color.rgb(255,235,230)); root.addView(warn);

        Button create = new Button(this); create.setText("ساخت کیف پول جدید (۱۲ کلمه)"); root.addView(create);
        recoveryInput = new EditText(this); recoveryInput.setHint("یا عبارت بازیابی ۱۲ کلمه‌ای را وارد کنید"); recoveryInput.setMinLines(2); recoveryInput.setGravity(Gravity.TOP); root.addView(recoveryInput);
        Button recover = new Button(this); recover.setText("بازیابی آدرس‌ها از عبارت واردشده"); root.addView(recover);

        mnemonicOut = addSection(root, "عبارت بازیابی — آن را به هیچ‌کس ندهید:");
        tronOut = addSection(root, "آدرس TRON (TRC20):");
        bscOut = addSection(root, "آدرس BNB Smart Chain (BEP20):");
        status = addSection(root, "وضعیت:");
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);

        create.setOnClickListener(v -> createWallet());
        recover.setOnClickListener(v -> recoverWallet());
    }

    private TextView addSection(LinearLayout root, String label) {
        TextView heading = new TextView(this); heading.setText(label); heading.setTypeface(null, Typeface.BOLD); heading.setTextSize(14); heading.setPadding(0,14,0,4); root.addView(heading);
        TextView value = new TextView(this); value.setText("—"); value.setTextIsSelectable(true); value.setTextSize(13); value.setTextColor(Color.rgb(25,45,70)); value.setPadding(10,8,10,8); value.setBackgroundColor(Color.WHITE); root.addView(value); return value;
    }

    private void createWallet() {
        try {
            byte[] entropy = new byte[16];
            new java.security.SecureRandom().nextBytes(entropy);
            String mnemonic = MnemonicUtils.generateMnemonic(entropy);
            recoveryInput.setText(mnemonic);
            showAddresses(mnemonic);
        } catch (Exception e) { status.setText("ایجاد ناموفق بود: " + e.getClass().getSimpleName()); }
    }

    private void recoverWallet() {
        String mnemonic = recoveryInput.getText().toString().trim().replaceAll("\\s+", " ").toLowerCase(java.util.Locale.ROOT);
        try {
            if (mnemonic.split(" ").length != 12) throw new IllegalArgumentException("عبارت باید ۱۲ کلمه داشته باشد.");
            if (!MnemonicUtils.validateMnemonic(mnemonic)) throw new IllegalArgumentException("عبارت بازیابی معتبر نیست یا checksum آن نادرست است.");
            showAddresses(mnemonic);
        } catch (Exception e) { status.setText("بازیابی نشد: " + e.getMessage()); }
    }

    private void showAddresses(String mnemonic) throws Exception {
        byte[] seed = MnemonicUtils.generateSeed(mnemonic, "");
        Bip32ECKeyPair master = Bip32ECKeyPair.generateKeyPair(seed);
        int h = Bip32ECKeyPair.HARDENED_BIT;
        Bip32ECKeyPair tronKey = Bip32ECKeyPair.deriveKeyPair(master, new int[]{44|h, 195|h, 0|h, 0, 0});
        Bip32ECKeyPair bscKey = Bip32ECKeyPair.deriveKeyPair(master, new int[]{44|h, 60|h, 0|h, 0, 0});
        String tron = tronAddress(tronKey);
        String bsc = "0x" + Keys.getAddress((ECKeyPair)bscKey);
        mnemonicOut.setText(mnemonic);
        tronOut.setText(tron);
        bscOut.setText(bsc);
        status.setText("آدرس‌ها از عبارت بازیابی مشتق شدند. موجودی و انتقال در این نسخه پشتیبانی نمی‌شوند.");
        Arrays.fill(seed, (byte)0);
    }

    private String tronAddress(ECKeyPair key) throws Exception {
        byte[] pub = Numeric.toBytesPadded(key.getPublicKey(), 64);
        byte[] hash = Numeric.hexStringToByteArray(Hash.sha3(pub));
        byte[] payload = new byte[21]; payload[0] = 0x41;
        System.arraycopy(hash, hash.length - 20, payload, 1, 20);
        byte[] first = MessageDigest.getInstance("SHA-256").digest(payload);
        byte[] second = MessageDigest.getInstance("SHA-256").digest(first);
        byte[] all = new byte[25]; System.arraycopy(payload,0,all,0,21); System.arraycopy(second,0,all,21,4);
        return base58(all);
    }

    private String base58(byte[] input) {
        final char[] alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz".toCharArray();
        BigInteger n = new BigInteger(1, input); StringBuilder out = new StringBuilder();
        BigInteger base = BigInteger.valueOf(58);
        while (n.signum() > 0) { BigInteger[] qr = n.divideAndRemainder(base); out.append(alphabet[qr[1].intValue()]); n = qr[0]; }
        for (byte b : input) { if (b == 0) out.append('1'); else break; }
        return out.reverse().toString();
    }
}
